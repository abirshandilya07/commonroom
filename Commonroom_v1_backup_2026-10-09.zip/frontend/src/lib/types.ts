import type {PublicIdentity,Envelope} from '../../../shared/crypto';
export type User = {id:string;name:string;username:string;encryptionReady?:boolean};
export type Member = User & {identity:PublicIdentity|null};
export type Conversation = {id:string;kind:'direct'|'group';title:string|null;createdBy:string;peer:User;members:Member[];lastMessage:string|null;lastMessageId:number;unreadCount:number;updatedAt:string};
export type WireMessage = {id:number;conversationId:string;senderId:string;clientId:string;body?:string;encrypted:Envelope|null;legacy:boolean;createdAt:string};
export type Message = Omit<WireMessage,'body'> & {body:string;decryptionError?:boolean};
export type MessagePage = {messages:WireMessage[];hasMore:boolean};
export type SendAck = {ok:true;message:WireMessage}|{ok:false;error:string};

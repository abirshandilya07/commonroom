import {useCallback,useEffect,useRef,useState} from 'react';
import {io,type Socket} from 'socket.io-client';
import {api,ApiError,post} from '../lib/api';
import {decrypt,encrypt,type UnlockedIdentity} from '../lib/encryption';
import type {Conversation,Message,MessagePage,SendAck,User,WireMessage} from '../lib/types';
import type {Envelope} from '../../../shared/crypto';
const merge=(a:Message[],b:Message[])=>[...new Map([...a,...b].map(m=>[m.id,m])).values()].sort((x,y)=>x.id-y.id);
export function useChat(user:User,identity:UnlockedIdentity,onExpired:()=>void,onIncoming:(m:WireMessage,c:Conversation)=>void) {
  const [conversations,setConversations]=useState<Conversation[]>([]),[activeId,setActiveId]=useState<string|null>(null);
  const [messages,setMessages]=useState<Record<string,Message[]>>({}),[hasMore,setHasMore]=useState<Record<string,boolean>>({});
  const [online,setOnline]=useState<string[]>([]),[connected,setConnected]=useState(false),[error,setError]=useState(''),[loading,setLoading]=useState(false);
  const [typing,setTyping]=useState<Record<string,Record<string,{name:string;until:number}>>>({});
  const socket=useRef<Socket|null>(null),activeRef=useRef(activeId),conversationRef=useRef(conversations),incomingRef=useRef(onIncoming);
  activeRef.current=activeId;incomingRef.current=onIncoming;
  const pending=useRef(new Map<string,{body:string;encrypted:Envelope}>());
  const fail=useCallback((e:unknown)=>{if(e instanceof ApiError&&e.status===401)onExpired();else setError(e instanceof Error?e.message:'Unable to connect.');},[onExpired]);
  const refreshConversations=useCallback(async()=>{
    const data=await api<{conversations:Conversation[]}>('/conversations');conversationRef.current=data.conversations;setConversations(data.conversations);return data.conversations;
  },[]);
  const findConversation=useCallback(async(id:string)=>{
    const list=conversationRef.current.some(c=>c.id===id)?conversationRef.current:await refreshConversations();
    const conversation=list.find(c=>c.id===id);if(!conversation)throw new Error('Conversation unavailable.');return conversation;
  },[refreshConversations]);
  const refreshHistory=useCallback(async(id:string)=>{
    const c=await findConversation(id),data=await api<MessagePage>(`/conversations/${id}/messages`);
    const decoded=await Promise.all(data.messages.map(m=>decrypt(identity,m,c))),newest=decoded.at(-1)?.id||0;
    setMessages(current=>({...current,[id]:merge(decoded,(current[id]||[]).filter(m=>m.id>newest))}));
    setHasMore(current=>({...current,[id]:data.hasMore}));
  },[identity,findConversation]);
  useEffect(()=>{
    const connection=io({transports:['websocket'],autoConnect:false});socket.current=connection;
    let alive=true,queue=Promise.resolve();
    connection.on('connect',()=>{setConnected(true);setError('');void refreshConversations().then(()=>{if(activeRef.current)return refreshHistory(activeRef.current);}).catch(fail);});
    connection.on('disconnect',(reason)=>{setConnected(false);setOnline([]);setTyping({});if(reason==='io server disconnect')onExpired();});
    connection.on('connect_error',e=>{setConnected(false);if(e.message==='Please sign in again.')onExpired();});
    connection.on('message:new',(wire:WireMessage)=>{
      queue=queue.then(async()=>{
        const list=await refreshConversations(),c=list.find(c=>c.id===wire.conversationId);if(!c||!alive)return;
        const message=await decrypt(identity,wire,c);if(!alive)return;
        setMessages(current=>({...current,[c.id]:merge(current[c.id]||[],[message])}));
        setTyping(current=>({...current,[c.id]:{...current[c.id],[wire.senderId]:{name:'',until:0}}}));
        if(wire.senderId!==user.id && (activeRef.current!==c.id||document.hidden||!document.hasFocus()))incomingRef.current(wire,c);
      }).catch(fail);
    });
    connection.on('conversation:changed',()=>{void refreshConversations().catch(fail);});
    connection.on('read:changed',()=>{void refreshConversations().catch(fail);});
    connection.on('presence:update',setOnline);
    connection.on('typing:update',(e:{conversationId:string;userId:string;name:string;typing:boolean})=>setTyping(current=>({...current,[e.conversationId]:{...current[e.conversationId],[e.userId]:{name:e.name,until:e.typing?Date.now()+2500:0}}})));
    connection.connect();
    const timer=setInterval(()=>setTyping(current=>Object.fromEntries(Object.entries(current).map(([id,people])=>[id,Object.fromEntries(Object.entries(people).filter(([,p])=>p.until>Date.now()))]))),1000);
    return()=>{alive=false;clearInterval(timer);connection.removeAllListeners();connection.disconnect();socket.current=null;};
  },[identity,user.id,fail,refreshConversations,refreshHistory,onExpired]);
  useEffect(()=>{if(!activeId)return;let cancelled=false;setLoading(true);void refreshHistory(activeId).catch(fail).finally(()=>{if(!cancelled)setLoading(false);});return()=>{cancelled=true;};},[activeId,refreshHistory,fail]);
  const lastRead=useRef(new Map<string,number>());
  const latest=activeId?messages[activeId]?.at(-1)?.id:undefined;
  useEffect(()=>{
    const read=()=>{
      if(!activeId||!latest||loading||document.hidden||!document.hasFocus()||(lastRead.current.get(activeId)||0)>=latest)return;
      lastRead.current.set(activeId,latest);
      void post(`/conversations/${activeId}/read`,{messageId:latest}).catch(e=>{lastRead.current.delete(activeId);fail(e);});
    };read();window.addEventListener('focus',read);document.addEventListener('visibilitychange',read);return()=>{window.removeEventListener('focus',read);document.removeEventListener('visibilitychange',read);};
  },[activeId,latest,loading,fail]);
  async function startChat(peer:User){const {id}=await post<{id:string}>('/conversations',{userId:peer.id});await refreshConversations();setActiveId(id);}
  async function createGroup(title:string,memberIds:string[]){const {id}=await post<{id:string}>('/groups',{title,memberIds});await refreshConversations();setActiveId(id);}
  async function older(){if(!activeId||!messages[activeId]?.length)return;const id=activeId,c=await findConversation(id),data=await api<MessagePage>(`/conversations/${id}/messages?before=${messages[id][0].id}`);const decoded=await Promise.all(data.messages.map(m=>decrypt(identity,m,c)));setMessages(current=>({...current,[id]:merge(decoded,current[id]||[])}));setHasMore(current=>({...current,[id]:data.hasMore}));}
  async function send(conversationId:string,body:string,clientId:string){
    if(!socket.current?.connected)throw new Error('You’re offline. Reconnect and retry.');
    const c=await findConversation(conversationId);
    const cached=pending.current.get(clientId);
    if(cached&&cached.body!==body)throw new Error('Retry text changed. Start a new message.');
    const encrypted=cached?.encrypted||await encrypt(identity,c,clientId,body);
    pending.current.set(clientId,{body,encrypted});
    const ack=await new Promise<SendAck>((resolve,reject)=>socket.current!.timeout(7000).emit('message:send',{conversationId,clientId,encrypted},(err:Error|null,result:SendAck)=>err?reject(new Error('Delivery not confirmed. Retry unchanged to check safely.')):resolve(result)));
    if(!ack.ok)throw new Error(ack.error);
    const message=await decrypt(identity,ack.message,c);setMessages(current=>({...current,[conversationId]:merge(current[conversationId]||[],[message])}));pending.current.delete(clientId);
  }
  const typingNames=activeId?Object.values(typing[activeId]||{}).filter(p=>p.until>Date.now()).map(p=>p.name):[];
  return {conversations,activeId,setActiveId,messages:activeId?messages[activeId]||[]:[],hasMore:activeId?!!hasMore[activeId]:false,typing:typingNames.length?`${typingNames.join(', ')} ${typingNames.length===1?'is':'are'} typing…`:'',online,connected,error,setError,loading,startChat,createGroup,older,send,
    emitTyping:(conversationId:string,value:boolean)=>socket.current?.connected&&socket.current.emit('typing:set',{conversationId,typing:value})};
}

import { useEffect, useRef, useState, type FormEvent } from 'react';
import { ArrowLeft, Send, Check, MessageSquare, Info, X, Search, LockKeyhole } from 'lucide-react';
import Avatar from './Avatar';
import { fingerprint } from '../lib/encryption';
import type { Conversation, Message, User } from '../lib/types';

type Props = {user: User; conversation: Conversation; messages: Message[]; connected: boolean; online: boolean; typing: string; loading: boolean; hasMore: boolean; onBack: () => void; onOlder: () => Promise<void>; onSend: (id: string, body: string, nonce: string) => Promise<void>; onTyping: (id: string, value: boolean) => void};
export default function ChatPanel(p: Props) {
  const [draft, setDraft] = useState('');
  const [fingerprints, setFingerprints] = useState<Record<string, string>>({});
  const group = p.conversation.kind === 'group';
  const ready = p.conversation.members.every(m => !!m.identity);
  useEffect(() => {let cancelled=false;void Promise.all(p.conversation.members.filter(m=>m.identity).map(async m=>[m.id,await fingerprint(m.identity!)] as const)).then(rows=>{if(!cancelled)setFingerprints(Object.fromEntries(rows));});return()=>{cancelled=true;};}, [p.conversation.members]);
  const [busy, setBusy] = useState(false);
  const [loadingOlder, setLoadingOlder] = useState(false);
  const [error, setError] = useState('');
  const [findOpen, setFindOpen] = useState(false);
  const [query, setQuery] = useState('');
  const retry = useRef<{body: string; id: string} | null>(null);
  const details = useRef<HTMLDialogElement>(null);
  const bottom = useRef<HTMLDivElement>(null);
  const lastId = p.messages.at(-1)?.id;
  const visible = query.trim() ? p.messages.filter((m) => m.body.toLowerCase().includes(query.trim().toLowerCase())) : p.messages;
  useEffect(() => {
    if (!query.trim()) bottom.current?.scrollIntoView({behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth'});
  }, [lastId, p.typing, query]);
  async function submit(event: FormEvent) {
    event.preventDefault();
    const body = draft.trim();
    if (!body || busy) return;
    const id = retry.current?.body === body ? retry.current.id : crypto.randomUUID();
    retry.current = {body, id}; setBusy(true); setError('');
    try { await p.onSend(p.conversation.id, body, id); setDraft(''); retry.current = null; p.onTyping(p.conversation.id, false); }
    catch (e) { setError(e instanceof Error ? e.message : 'Unable to send.'); }
    finally { setBusy(false); }
  }
  return <section className="flex h-full min-w-0 flex-1 flex-col bg-canvas text-ink">
    <header className="flex h-[72px] shrink-0 items-center gap-3 border-b border-line px-3 sm:px-6">
      <button aria-label="Back to conversations" className="icon-button md:hidden" onClick={p.onBack}><ArrowLeft size={19}/></button>
      <Avatar name={p.conversation.peer.name} online={group ? undefined : p.online}/>
      <div className="min-w-0 flex-1"><h2 className="truncate text-base font-bold">{p.conversation.peer.name}</h2><p className="mt-0.5 text-[11px] text-muted">{group ? `${p.conversation.members.length} members` : p.online ? 'Active now' : 'Offline'}<span className="mx-1.5">·</span>{group ? 'Group chat' : 'Direct message'}</p></div>
      <button aria-label="Find in loaded messages" title="Find in loaded messages" aria-expanded={findOpen} className="icon-button" onClick={() => {setFindOpen(!findOpen); setQuery('');}}><Search size={18}/></button>
      <button aria-label="Conversation details" title="Conversation details" className="icon-button" onClick={() => details.current?.showModal()}><Info size={18}/></button>
    </header>
    <div className="flex h-10 shrink-0 items-center gap-4 border-b border-line px-5 text-xs sm:px-7"><span className="flex h-full items-center gap-1.5 border-b-2 border-accent font-semibold"><MessageSquare size={13}/>Messages</span><span className="ml-auto flex items-center gap-1 text-[10px] text-muted"><LockKeyhole size={11}/>{ready ? 'New messages encrypted' : 'Encryption setup needed'}</span></div>
    {findOpen && <div className="flex items-center gap-2 border-b border-line bg-soft px-4 py-2"><Search size={15} className="text-muted"/><input autoFocus aria-label="Search loaded messages" className="min-w-0 flex-1 bg-transparent py-1 text-xs" placeholder="Search loaded messages…" value={query} onChange={(e) => setQuery(e.target.value)}/><span className="shrink-0 text-[10px] text-muted">{visible.length} found</span><button aria-label="Close message search" className="icon-button h-7 w-7" onClick={() => {setFindOpen(false); setQuery('');}}><X size={14}/></button></div>}
    {p.messages.some(m=>m.legacy)&&<p className="warning-notice mx-4 mt-2">Earlier messages were sent before encryption was enabled. They remain readable and are not end-to-end encrypted.</p>}
    <div className="min-h-0 flex-1 overflow-y-auto pb-4 pt-5" role="log" aria-label="Messages" aria-live="polite">
      {p.hasMore && <div className="mb-5 text-center"><button disabled={loadingOlder} className="secondary-button px-3 py-1.5 text-[11px]" onClick={async () => {setLoadingOlder(true); try {await p.onOlder();} catch (e) {setError(e instanceof Error ? e.message : 'Unable to load history.');} finally {setLoadingOlder(false);}}}>{loadingOlder ? 'Loading…' : 'Load earlier messages'}</button></div>}
      {!p.hasMore && !query.trim() && <div className="px-5 pb-7 pt-3 sm:px-7"><Avatar name={p.conversation.peer.name} large/><h3 className="mt-4 text-2xl font-bold tracking-tight">{p.conversation.peer.name}</h3><p className="mt-1 text-xs text-muted">{group ? `${p.conversation.members.length} members` : `@${p.conversation.peer.username}`}</p><p className="mt-3 max-w-xl text-[13px] leading-6 text-muted">{group ? `Welcome to ${p.conversation.peer.name}. New messages are encrypted for all ${p.conversation.members.length} members.` : `Your direct conversation with ${p.conversation.peer.name}. New messages are encrypted on your devices.`}</p></div>}
      {p.loading && !p.messages.length && <p className="px-7 py-5 text-xs text-muted">Loading your conversation…</p>}
      {query.trim() && !visible.length && <p className="px-7 py-8 text-sm text-muted">No matches in the loaded messages. You can load earlier messages to search further back.</p>}
      {visible.map((m, index) => {
        const own = m.senderId === p.user.id;
        const date = new Date(m.createdAt);
        const prev = visible[index - 1];
        const showDate = !prev || date.toDateString() !== new Date(prev.createdAt).toDateString();
        const grouped = !query.trim() && !showDate && prev?.senderId === m.senderId && date.getTime() - new Date(prev.createdAt).getTime() < 300000;
        const author = p.conversation.members.find(member => member.id === m.senderId) || (own ? p.user : {name:'Unknown sender'});
        return <div key={m.id}>
          {showDate && <div className="relative my-4 flex items-center px-5 sm:px-7"><span className="h-px flex-1 bg-line"/><span className="rounded-full border border-line bg-canvas px-3 py-1 text-[10px] font-semibold">{date.toLocaleDateString(undefined, {weekday: 'long', month: 'long', day: 'numeric'})}</span><span className="h-px flex-1 bg-line"/></div>}
          <article className={`message-row ${grouped ? 'py-1' : ''}`}>
            {grouped ? <span className="w-9 shrink-0 pt-1 text-right text-[9px] text-muted"><time dateTime={m.createdAt}>{date.toLocaleTimeString(undefined, {hour: '2-digit', minute: '2-digit', hour12: false})}</time></span> : <Avatar name={author.name}/>}
            <div className="min-w-0 flex-1">
              {!grouped && <p className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[13px]"><span className="font-bold">{author.name}</span>{own && <span className="text-[10px] text-muted">(you)</span>}<time className="text-[10px] text-muted" dateTime={m.createdAt}>{date.toLocaleTimeString(undefined, {hour: '2-digit', minute: '2-digit'})}</time>{own && <Check aria-label="Saved on server" className="text-success" size={11}/>}<span className="text-[9px] text-muted">{m.legacy ? 'Earlier · unencrypted' : m.decryptionError ? 'Verification failed' : 'Encrypted'}</span></p>}
              <p className={`${m.decryptionError ? "text-red-500" : ""} whitespace-pre-wrap break-words text-[13px] leading-[1.65] [overflow-wrap:anywhere] ${grouped ? '' : 'mt-0.5'}`}>{m.body}</p>
            </div>
          </article>
        </div>;
      })}
      {p.typing && <p className="mt-3 px-7 text-[11px] text-muted">{p.typing}</p>}<div ref={bottom}/>
    </div>
    <form onSubmit={submit} className="shrink-0 bg-canvas px-3 pb-3 pt-2 sm:px-5 sm:pb-4">
      {error && <p role="alert" className="error-notice mb-2">{error}</p>}
      {!ready && <p className="warning-notice mb-2">Every member must sign in and complete encryption setup before new messages can be sent.</p>}
      {!p.connected && <p role="status" className="warning-notice mb-2">Reconnecting… Your draft stays here.</p>}
      <div className="overflow-hidden rounded-xl border border-line bg-panel focus-within:border-accent focus-within:ring-1 focus-within:ring-accent">
        <textarea aria-label="Message" placeholder={`Message ${p.conversation.peer.name}`} rows={2} maxLength={2000} disabled={busy} value={draft} onChange={(e) => {setDraft(e.target.value); p.onTyping(p.conversation.id, !!e.target.value.trim());}} onKeyDown={(e) => {if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing) {e.preventDefault(); void submit(e);}}} className="block max-h-36 min-h-[70px] w-full resize-none bg-transparent px-4 pb-2 pt-3 text-[13px] leading-6"/>
        <div className="flex items-center justify-between px-3 pb-2"><span className="text-[10px] text-muted">{draft.length > 0 ? `${draft.length.toLocaleString()} / 2,000` : 'Make a little room for a good conversation.'}</span><button type="submit" disabled={busy || !ready || !p.connected || !draft.trim()} aria-label={busy ? 'Sending message' : error ? 'Retry message' : 'Send message'} className="primary-button rounded-md px-3 py-2"><Send size={15}/><span className="hidden text-xs sm:inline">Send</span></button></div>
      </div>
      <p className="mt-1.5 text-right text-[10px] text-muted"><span className="font-semibold">Enter</span> to send · <span className="font-semibold">Shift + Enter</span> for a new line</p>
    </form>
    <dialog ref={details} className="dialog-panel max-w-xl" aria-labelledby="details-title"><div className="flex items-center justify-between"><h2 id="details-title" className="text-base font-bold">Conversation details</h2><button aria-label="Close conversation details" className="icon-button" onClick={() => details.current?.close()}><X size={18}/></button></div>
      <h3 className="mt-4 text-xl font-bold">{p.conversation.peer.name}</h3><p className="mt-2 text-xs leading-6 text-muted">{group ? 'Group membership is fixed in this version. Create a new group for a different set of people.' : 'A private direct conversation.'} Compare fingerprints with each participant through a separate, trusted channel. Messages are signed and encrypted in your browser. This prototype has not been independently audited and does not provide forward secrecy.</p>
      <div className="mt-4 max-h-80 space-y-3 overflow-y-auto">{p.conversation.members.map(member=><div key={member.id} className="rounded-lg border border-line bg-soft p-3"><div className="flex items-center gap-2"><Avatar name={member.name} small/><p className="text-sm font-semibold">{member.name}{member.id===p.user.id?' (you)':''}</p></div><p className="mt-2 text-[10px] text-muted">Encryption identity fingerprint · compare the full value</p><code className="mt-1 block break-words text-[10px] leading-5 text-muted">{fingerprints[member.id]||'Encryption setup not completed'}</code></div>)}</div>
      <p className="mt-4 text-xs leading-6 text-muted">A checkmark means saved on the server, not read. The server can see membership, sender IDs, timestamps, and message sizes; new message text stays encrypted.</p></dialog>
  </section>;
}

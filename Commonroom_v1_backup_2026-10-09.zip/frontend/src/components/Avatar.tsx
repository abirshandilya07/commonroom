export default function Avatar({name, online, large = false, small = false}: {name: string; online?: boolean; large?: boolean; small?: boolean}) {
  const initials = name.trim().split(/\s+/).slice(0, 2).map((s) => s[0]).join('').toUpperCase();
  const palettes = ['bg-[#deebe4] text-[#2c6950] dark:bg-[#29483d] dark:text-[#b0e0c7]', 'bg-[#eadcf3] text-[#764791] dark:bg-[#493452] dark:text-[#dec0ef]', 'bg-[#dce8f6] text-[#3f6691] dark:bg-[#30435d] dark:text-[#b7d5f9]', 'bg-[#f3e2d5] text-[#945c35] dark:bg-[#503f33] dark:text-[#edc9aa]'];
  const color = palettes[[...name].reduce((sum, c) => sum + c.charCodeAt(0), 0) % palettes.length];
  return <span className={`relative grid shrink-0 place-items-center rounded-lg font-semibold ${color} ${large ? 'h-16 w-16 text-xl' : small ? 'h-7 w-7 text-[10px]' : 'h-9 w-9 text-xs'}`}>
    {initials}{online !== undefined && <span aria-label={online ? 'Online' : 'Offline'} className={`absolute -bottom-0.5 -right-0.5 h-2.5 w-2.5 rounded-full border-2 border-panel ${online ? 'bg-success' : 'bg-muted'}`} />}
  </span>;
}

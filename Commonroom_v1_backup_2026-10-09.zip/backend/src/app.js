import express from 'express';
import helmet from 'helmet';
import { rateLimit } from 'express-rate-limit';
import { createServer } from 'node:http';
import { randomUUID, createPublicKey } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { existsSync } from 'node:fs';
import { Server } from 'socket.io';
import { z } from 'zod';
import { openDatabase } from './db.js';
import { hashPassword, verifyPassword, publicUser, findSession, createSession, clearSession } from './auth.js';
import { conversationFor, messageView, saveMessage, membersFor, identityInput } from './chat.js';

import {MAX_GROUP_MEMBERS, MAX_ENCRYPTED_PACKET_BYTES} from '../../shared/limits.js';

const credentials = z.object({username: z.string().trim().toLowerCase().regex(/^[a-z0-9_]{3,24}$/), password: z.string().min(8).max(128)});
const registration = credentials.extend({name: z.string().trim().min(2).max(40)});
const room = (id) => `user:${id}`;

export function createApplication({databasePath = './data/commonroom.sqlite', origins = ['http://localhost:5173'], secureCookie = false, trustProxy = false} = {}) {
  const db = openDatabase(databasePath);
  const app = express();
  const http = createServer(app);
  const io = new Server(http, {
    transports: ['websocket'], maxHttpBufferSize: MAX_ENCRYPTED_PACKET_BYTES,
    allowRequest: (req, done) => done(null, origins.includes(req.headers.origin)),
  });
  app.disable('x-powered-by');
  if (trustProxy) app.set('trust proxy', 1);
  app.use(helmet());
  app.use(express.json({limit: MAX_ENCRYPTED_PACKET_BYTES}));
  app.use('/api', (_req, res, next) => {res.setHeader('Cache-Control', 'no-store'); next();});
  app.use('/api', rateLimit({windowMs: 60_000, limit: 240, standardHeaders: 'draft-8', legacyHeaders: false, message: {error: 'Too many requests. Try again in a minute.'}}));
  app.use('/api', (req, res, next) => {
    // Browser writes must come from our own frontend. No permissive CORS.
    if (!['GET', 'HEAD', 'OPTIONS'].includes(req.method) && !origins.includes(req.headers.origin)) return res.status(403).json({error: 'Origin not allowed.'});
    next();
  });
  const authLimiter = rateLimit({windowMs: 15 * 60_000, limit: 30, standardHeaders: 'draft-8', legacyHeaders: false, message: {error: 'Too many sign-in attempts. Please try again later.'}});
  const requireUser = (req, res, next) => {
    req.user = findSession(db, req.headers);
    if (!req.user) return res.status(401).json({error: 'Please sign in again.'});
    next();
  };
  app.get('/api/health', (_req, res) => res.json({ok: true}));
  app.post('/api/auth/register', authLimiter, async (req, res) => {
    const input = registration.parse(req.body);
    const passwordHash = await hashPassword(input.password);
    const user = {id: randomUUID(), name: input.name, username: input.username};
    // The UNIQUE constraint also handles two concurrent registrations.
    try {
      db.prepare('INSERT INTO users VALUES (?, ?, ?, ?, ?)').run(user.id, user.name, user.username, passwordHash, new Date().toISOString());
    } catch (error) {
      if (String(error.message).includes('UNIQUE')) return res.status(409).json({error: 'That username is already taken.'});
      throw error;
    }
    createSession(db, user.id, res, secureCookie);
    res.status(201).json({user});
  });
  app.post('/api/auth/login', authLimiter, async (req, res) => {
    const input = credentials.parse(req.body);
    const user = db.prepare('SELECT * FROM users WHERE username = ?').get(input.username);
    if (!user || !(await verifyPassword(input.password, user.password_hash))) return res.status(401).json({error: 'Username or password is incorrect.'});
    createSession(db, user.id, res, secureCookie);
    res.json({user: publicUser(user)});
  });
  app.get('/api/auth/me', requireUser, (req, res) => res.json({user: publicUser(req.user)}));
  app.post('/api/auth/logout', requireUser, (req, res) => {
    db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(req.user.token_hash);
    io.in(`session:${req.user.token_hash}`).disconnectSockets(true);
    clearSession(res, secureCookie);
    res.json({ok: true});
  });
  app.get('/api/identity', requireUser, (req,res) => {
    const record=db.prepare('SELECT * FROM identities WHERE user_id=?').get(req.user.id);
    res.json({identity:record?{...JSON.parse(record.public_keys),vault:JSON.parse(record.vault)}:null});
  });
  app.post('/api/identity', requireUser, (req,res) => {
    const input=identityInput.parse(req.body);
    const publicKeys={encryptionKey:input.encryptionKey,signingKey:input.signingKey};
    try {
      const rsa=createPublicKey({key:input.encryptionKey,format:'jwk'});
      const ec=createPublicKey({key:input.signingKey,format:'jwk'});
      if(rsa.asymmetricKeyDetails?.modulusLength!==2048 || ec.asymmetricKeyType!=='ec') throw new Error();
    } catch {return res.status(400).json({error:'Invalid public keys.'});}
    if(db.prepare('SELECT user_id FROM identities WHERE user_id=?').get(req.user.id)) return res.status(409).json({error:'Encryption is already set up. Use your existing recovery key.'});
    db.prepare('INSERT INTO identities VALUES(?,?,?,?)').run(req.user.id,JSON.stringify(publicKeys),JSON.stringify(input.vault),new Date().toISOString());
    io.emit('conversation:changed');
    res.status(201).json({ok:true});
  });
  app.get('/api/users', requireUser, (req,res) => {
    const query=typeof req.query.q==='string'?req.query.q.slice(0,40):'';
    const offset=z.coerce.number().int().min(0).max(1000000).parse(req.query.offset ?? 0);
    const users=db.prepare(`SELECT u.id,u.name,u.username, i.public_keys FROM users u LEFT JOIN identities i ON i.user_id=u.id WHERE u.id!=? AND (instr(lower(u.name),lower(?))>0 OR instr(u.username,lower(?))>0) ORDER BY u.name,u.id LIMIT 51 OFFSET ?`).all(req.user.id,query,query,offset).map(u=>({id:u.id,name:u.name,username:u.username,encryptionReady:!!u.public_keys}));
    res.json({users:users.slice(0,50),hasMore:users.length>50});
  });
  app.get('/api/conversations', requireUser, (req,res) => {
    const rows=db.prepare(`SELECT c.*,
      (SELECT MAX(id) FROM messages WHERE conversation_id=c.id) AS last_message_id,
      (SELECT encrypted_payload IS NOT NULL FROM messages WHERE conversation_id=c.id ORDER BY id DESC LIMIT 1) AS encrypted,
      COALESCE((SELECT created_at FROM messages WHERE conversation_id=c.id ORDER BY id DESC LIMIT 1),c.created_at) AS updated_at,
      (SELECT COUNT(*) FROM messages WHERE conversation_id=c.id AND id>m.last_read_id AND sender_id!=?) AS unread_count
      FROM conversations c JOIN conversation_members m ON m.conversation_id=c.id WHERE m.user_id=? ORDER BY updated_at DESC`).all(req.user.id,req.user.id);
    res.json({conversations:rows.map(c=>{
      const members=membersFor(db,c.id);
      return {id:c.id,kind:c.kind,title:c.title,members,createdBy:c.created_by,
        peer:c.kind==='direct'?members.find(m=>m.id!==req.user.id):{id:c.id,name:c.title,username:`${members.length} members`},
        lastMessage:c.last_message_id?(c.encrypted?'Encrypted message':'Earlier unencrypted message'):null,lastMessageId:c.last_message_id||0,unreadCount:c.unread_count,updatedAt:c.updated_at};
    })});
  });
  app.post('/api/conversations', requireUser, (req,res) => {
    const {userId}=z.object({userId:z.string().uuid()}).parse(req.body);
    if(userId===req.user.id) return res.status(400).json({error:'Choose another person.'});
    if(!db.prepare('SELECT id FROM users WHERE id=?').get(userId)) return res.status(404).json({error:'User not found.'});
    const [a,b]=[req.user.id,userId].sort();
    const existing=db.prepare("SELECT id FROM conversations WHERE kind='direct' AND user_a=? AND user_b=?").get(a,b);
    if(existing) return res.json(existing);
    if(![a,b].every(id=>db.prepare('SELECT user_id FROM identities WHERE user_id=?').get(id))) return res.status(409).json({error:'Both people need to set up encryption first.'});
    const id=randomUUID();
    db.exec('BEGIN IMMEDIATE');
    try {
      db.prepare("INSERT INTO conversations(id,user_a,user_b,created_at,kind,created_by) VALUES(?,?,?,?,'direct',?)").run(id,a,b,new Date().toISOString(),req.user.id);
      for(const user of [a,b]) db.prepare('INSERT INTO conversation_members(conversation_id,user_id) VALUES(?,?)').run(id,user);
      db.exec('COMMIT');
    } catch(e) {db.exec('ROLLBACK');throw e;}
    io.to(room(a)).to(room(b)).emit('conversation:changed'); res.status(201).json({id});
  });
  app.post('/api/groups', requireUser, (req,res) => {
    const input=z.object({title:z.string().trim().min(2).max(60),memberIds:z.array(z.string().uuid()).min(2).max(MAX_GROUP_MEMBERS - 1).refine(a=>new Set(a).size===a.length)}).strict().parse(req.body);
    if(input.memberIds.includes(req.user.id)) return res.status(400).json({error:'You are included automatically.'});
    const users=[req.user.id,...input.memberIds];
    if(!users.every(id=>db.prepare('SELECT user_id FROM identities WHERE user_id=?').get(id))) return res.status(409).json({error:'Every selected person needs to set up encryption first.'});
    const id=randomUUID();db.exec('BEGIN IMMEDIATE');
    try {
      db.prepare("INSERT INTO conversations(id,created_at,kind,title,created_by) VALUES(?,?,'group',?,?)").run(id,new Date().toISOString(),input.title,req.user.id);
      for(const user of users) db.prepare('INSERT INTO conversation_members(conversation_id,user_id) VALUES(?,?)').run(id,user);
      db.exec('COMMIT');
    } catch(e) {db.exec('ROLLBACK');throw e;}
    io.to(users.map(room)).emit('conversation:changed');res.status(201).json({id});
  });
  app.post('/api/conversations/:id/read',requireUser,(req,res)=>{
    if(!conversationFor(db,req.params.id,req.user.id)) return res.status(404).json({error:'Conversation not found.'});
    const {messageId}=z.object({messageId:z.number().int().positive()}).parse(req.body);
    if(!db.prepare('SELECT id FROM messages WHERE id=? AND conversation_id=?').get(messageId,req.params.id)) return res.status(400).json({error:'Invalid message cursor.'});
    db.prepare('UPDATE conversation_members SET last_read_id=MAX(last_read_id,?) WHERE conversation_id=? AND user_id=?').run(messageId,req.params.id,req.user.id);
    io.to(room(req.user.id)).emit('read:changed');res.json({ok:true});
  });
  app.get('/api/conversations/:id/messages', requireUser, (req, res) => {
    if (!conversationFor(db, req.params.id, req.user.id)) return res.status(404).json({error: 'Conversation not found.'});
    const before = z.coerce.number().int().positive().safeParse(req.query.before ?? Number.MAX_SAFE_INTEGER);
    if (!before.success) return res.status(400).json({error: 'Invalid message cursor.'});
    const rows = db.prepare('SELECT * FROM messages WHERE conversation_id = ? AND id < ? ORDER BY id DESC LIMIT 51').all(req.params.id, before.data);
    const hasMore = rows.length > 50;
    res.json({messages: rows.slice(0, 50).reverse().map(messageView), hasMore});
  });

  const online = new Map();
  io.use((socket, next) => {
    const user = findSession(db, socket.request.headers);
    if (!user) return next(new Error('Please sign in again.'));
    socket.data.user = user;
    next();
  });
  io.on('connection', (socket) => {
    const user = socket.data.user;
    socket.join(room(user.id));
    socket.join(`session:${user.token_hash}`);
    online.set(user.id, (online.get(user.id) || 0) + 1);
    io.emit('presence:update', [...online.keys()]);
    const expiry = setTimeout(() => socket.disconnect(true), Math.max(0, user.expires_at - Date.now()));
    // Re-check the session for every action, including on already-connected sockets.
    socket.use((_packet, next) => {
      if (!findSession(db, socket.request.headers)) {socket.disconnect(true); return;}
      next();
    });
    let messageWindow = Date.now();
    let messageCount = 0;
    socket.on('message:send', (input, callback) => {
      const reply = typeof callback === 'function' ? callback : () => {};
      if (Date.now() - messageWindow >= 60_000) {messageWindow = Date.now(); messageCount = 0;}
      if (++messageCount > 60) return reply({ok: false, error: 'Slow down a little. Try again in a minute.'});
      try {
        const result = saveMessage(db, user.id, input);
        if (result.isNew) io.to(result.members.map(m=>room(m.id))).emit('message:new', result.message);
        reply({ok: true, message: result.message});
      } catch (error) {
        reply({ok: false, error: error instanceof z.ZodError ? 'Invalid encrypted message. Update your client; plaintext sends are disabled.' : error.message});
      }
    });
    let lastTyping = 0;
    socket.on('typing:set', (input) => {
      if (Date.now() - lastTyping < 500) return;
      lastTyping = Date.now();
      const parsed = z.object({conversationId: z.string().uuid(), typing: z.boolean()}).safeParse(input);
      if (!parsed.success) return;
      const c = conversationFor(db, parsed.data.conversationId, user.id);
      if (!c) return;
      io.to(membersFor(db,c.id).filter(m=>m.id!==user.id).map(m=>room(m.id))).emit('typing:update', {conversationId:c.id,userId:user.id,name:user.name,typing:parsed.data.typing});
    });
    socket.on('disconnect', () => {
      clearTimeout(expiry);
      const count = (online.get(user.id) || 1) - 1;
      if (count <= 0) online.delete(user.id); else online.set(user.id, count);
      io.emit('presence:update', [...online.keys()]);
    });
  });

  app.use('/api', (_req, res) => res.status(404).json({error: 'Endpoint not found.'}));
  const dist = fileURLToPath(new URL('../../frontend/dist/', import.meta.url));
  if (existsSync(dist)) app.use(express.static(dist));
  app.use((error, _req, res, _next) => {
    if (error instanceof z.ZodError) return res.status(400).json({error: 'Invalid input. Check the fields and try again.'});
    if (error.type === 'entity.parse.failed') return res.status(400).json({error: 'Invalid JSON.'});
    if (error.type === 'entity.too.large') return res.status(413).json({error: 'Request is too large.'});
    console.error(error);
    res.status(500).json({error: 'Something went wrong. Please try again.'});
  });
  return {app, http, io, db, close: async () => {
    await new Promise((resolve) => io.close(resolve));
    db.close();
  }};
}

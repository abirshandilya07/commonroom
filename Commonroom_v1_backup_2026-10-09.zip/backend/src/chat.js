import { z } from 'zod';
import { createPublicKey, verify } from 'node:crypto';
import { unsignedEnvelope } from '../../shared/crypto.js';
import {MAX_GROUP_MEMBERS} from '../../shared/limits.js';
const base64=z.string().regex(/^[A-Za-z0-9+/]+={0,2}$/);
const publicRsa=z.object({kty:z.literal('RSA'),n:z.string().regex(/^[A-Za-z0-9_-]{342}$/),e:z.literal('AQAB')}).strict();
const publicEc=z.object({kty:z.literal('EC'),crv:z.literal('P-256'),x:z.string().regex(/^[A-Za-z0-9_-]{43}$/),y:z.string().regex(/^[A-Za-z0-9_-]{43}$/)}).strict();
export const identityInput=z.object({encryptionKey:publicRsa,signingKey:publicEc,vault:z.object({version:z.literal(1),iv:base64.length(16),ciphertext:base64.min(100).max(16000)}).strict()}).strict();
export const messageInput=z.object({conversationId:z.string().uuid(),clientId:z.string().uuid(),encrypted:z.object({version:z.literal(1),conversationId:z.string().uuid(),senderId:z.string().uuid(),clientId:z.string().uuid(),iv:base64.length(16),ciphertext:base64.min(24).max(11000),recipients:z.array(z.object({userId:z.string().uuid(),key:base64.length(344)}).strict()).min(2).max(MAX_GROUP_MEMBERS),signature:base64.length(88)}).strict()}).strict();
export const membersFor=(db,id)=>db.prepare(`SELECT u.id,u.name,u.username,i.public_keys FROM conversation_members m JOIN users u ON u.id=m.user_id LEFT JOIN identities i ON i.user_id=u.id WHERE m.conversation_id=? ORDER BY u.id`).all(id).map(u=>({id:u.id,name:u.name,username:u.username,identity:u.public_keys?JSON.parse(u.public_keys):null}));
export const conversationFor=(db,id,userId)=>db.prepare('SELECT c.* FROM conversations c JOIN conversation_members m ON m.conversation_id=c.id WHERE c.id=? AND m.user_id=?').get(id,userId);
export const messageView=m=>({id:m.id,conversationId:m.conversation_id,senderId:m.sender_id,clientId:m.client_id,body:m.encrypted_payload?undefined:m.body,encrypted:m.encrypted_payload?JSON.parse(m.encrypted_payload):null,legacy:!m.encrypted_payload,createdAt:m.created_at});
export function saveMessage(db,userId,input) {
  const {conversationId,clientId,encrypted}=messageInput.parse(input);
  const conversation=conversationFor(db,conversationId,userId);
  if(!conversation) throw new Error('Conversation not found.');
  if(encrypted.senderId!==userId || encrypted.conversationId!==conversationId || encrypted.clientId!==clientId) throw new Error('Invalid encrypted message context.');
  const members=membersFor(db,conversationId);
  if(members.some(m=>!m.identity)) throw new Error('Every member must set up encryption before you can send.');
  const targets=encrypted.recipients.map(r=>r.userId).sort();
  if(JSON.stringify(targets)!==JSON.stringify(members.map(m=>m.id).sort())) throw new Error('Encrypt for exactly the conversation members.');
  const sender=members.find(m=>m.id===userId);
  const publicKey=createPublicKey({key:sender.identity.signingKey,format:'jwk'});
  if(!verify('sha256',Buffer.from(unsignedEnvelope(encrypted)),{key:publicKey,dsaEncoding:'ieee-p1363'},Buffer.from(encrypted.signature,'base64'))) throw new Error('Invalid message signature.');
  const serialized=JSON.stringify(encrypted);
  const existing=db.prepare('SELECT * FROM messages WHERE sender_id=? AND client_id=?').get(userId,clientId);
  if(existing) {
    if(existing.conversation_id!==conversationId || existing.encrypted_payload!==serialized) throw new Error('Message ID already used.');
    return {message:messageView(existing),members,isNew:false};
  }
  const result=db.prepare('INSERT INTO messages(conversation_id,sender_id,client_id,body,created_at,encrypted_payload) VALUES(?,?,?,?,?,?)').run(conversationId,userId,clientId,'[Encrypted message]',new Date().toISOString(),serialized);
  return {message:messageView(db.prepare('SELECT * FROM messages WHERE id=?').get(result.lastInsertRowid)),members,isNew:true};
}
